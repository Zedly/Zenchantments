package zedly.zenchantments;

import java.io.*;
import java.net.*;
import java.security.CodeSource;
import java.util.*;
import java.util.logging.*;
import java.util.zip.*;

public class Language {

    private String id;

    private List<List<String>> commands;
    private List<String> templates;
    //private List<List<String>> templates;

    private static final List<Language> LANGUAGES = new ArrayList<>();

    public static void saveDefaultLanguages() {
        new File("plugins/Zenchantments/languages").mkdir();
        CodeSource src = Zenchantments.class.getProtectionDomain().getCodeSource();
        List<String> list = new ArrayList<String>();
        if (src != null) {
            URL jar = src.getLocation();
            ZipInputStream zip;
            try {
                zip = new ZipInputStream(jar.openStream());
                ZipEntry ze;
                while ((ze = zip.getNextEntry()) != null) {
                    String entryName = ze.getName();
                    if (entryName.startsWith("resource/lang_") && entryName.endsWith(".txt")) {
                        list.add(entryName);
                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(Language.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        for (String s : list) {
            LANGUAGES.add(new Language(Utilities.saveResource("/" + s, "plugins/Zenchantments/languages/"
                    + s.replace("resource/", "")), s.replace("resource/lang_", "").replace(".txt", "")));
        }
    }

    public static String getTranslation(Language language, int id, List<String> parameters) {
        return null;
    }

    public Language(String contents, String name) {
        id = name;
        Scanner s = new Scanner(contents);
        templates = new ArrayList<>();
        while (s.hasNextLine()) {
            String str = s.nextLine();
            if (!str.contains("**")) {
                commands.add(getSplit(str));
            }
        }
    }

    private static List<String> getSplit(String format) {
        List<String> parts = new ArrayList<>();
        boolean canRead = !format.substring(0, 2).equals("@<");
        boolean delete = false;
        String current = "";
        for (int i = 0; i < format.length() - 1; i++) {
            if (format.charAt(i) == '@' && format.charAt(i + 1) == '<') {
                canRead = false;
                if (!current.isEmpty()) {
                    parts.add(current);
                    current = "";
                }
            } else if (format.charAt(i) == '@' && format.charAt(i + 1) == '>') {
                canRead = true;
                delete = true;
                parts.add("@<?>");
            } else if (canRead) {
                if (delete) {
                    delete = false;
                } else {
                    current += format.charAt(i);
                }
            }
        }
        if (canRead) {
            current += format.charAt(format.length() - 1);
        }
        parts.add(current);
        return parts;
    }

}
